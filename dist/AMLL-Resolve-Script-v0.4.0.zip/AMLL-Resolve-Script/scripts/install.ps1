﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$DestinationRoot = "$env:APPDATA\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts",
    [string]$BackupRoot = 'D:\CodexBackup'
)
$ErrorActionPreference = 'Stop'
$source = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$utility = [IO.Path]::GetFullPath((Join-Path $DestinationRoot 'Utility'))
$scriptTarget = Join-Path $utility 'AMLL 歌词助手.py'
$appTarget = Join-Path $utility 'AMLL-Lyrics-App'
$oldTargets = @(
    $scriptTarget,
    $appTarget,
    (Join-Path $env:PROGRAMDATA 'Blackmagic Design\DaVinci Resolve\Support\Workflow Integration Plugins\com.edgehh.amll.lyrics'),
    (Join-Path $env:APPDATA 'Blackmagic Design\DaVinci Resolve\Support\Workflow Integration Plugins\com.edgehh.amll.lyrics')
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
function Backup-And-Remove([string]$path) {
    $backup = Join-Path $BackupRoot ('amll-old-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Copy-Item -LiteralPath $path -Destination (Join-Path $backup (Split-Path -Leaf $path)) -Recurse -Force
    Remove-Item -LiteralPath $path -Recurse -Force
    Write-Host "旧安装已备份并删除：$path"
}
foreach ($path in $oldTargets) { Backup-And-Remove $path }
New-Item -ItemType Directory -Path $utility,$appTarget -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $source 'script-host.py') -Destination $scriptTarget -Force
foreach ($name in @('main.js','preload.js','manifest.xml','package.json','package-lock.json','README.md','THIRD_PARTY_NOTICES.md','lib','ui','adapters','node_modules','docs')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination $appTarget -Recurse -Force
}
Write-Host "AMLL 歌词助手 Scripts 已安装到：$scriptTarget"
Write-Host '请完全重启 DaVinci Resolve，然后从 工作区 → 脚本 → Utility → AMLL 歌词助手 打开。'
